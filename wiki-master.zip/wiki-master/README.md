### Wiki Build Status | [![](https://travis-ci.org/MindustryGame/wiki.svg?branch=master)](https://travis-ci.org/MindustryGame/wiki)
This is the wiki page for Mindustry.
