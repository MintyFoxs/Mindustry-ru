# <img id="spr" src="/wiki/images/mech-alpha-mech-full.png"></img> Alpha


*"The standard control mech. Based on a Dagger unit, with upgraded armor and building capabilities. Has more damage output than a Dart ship."*  

| Property      | Value |
| ----------- | ----------- |
|Internal Name|`alpha-mech`|
|Health|250|
|Speed|0.5|
|Mass|1.2|
|Max Velocity|10|
|Item Capacity|40|
|Drill Power|1|
|Mine Speed|150%|
|Build Speed|120%|

--- 

##### Created in <br><a href="/wiki/blocks/upgrade/dart-mech-pad"><img id="sprlist" src="/wiki/images/block-dart-mech-pad-small.png"/></a> 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)