# <img id="spr" src="/wiki/images/mech-javelin-ship-full.png"></img> Javelin


*"A hit-and-run strike ship. While initially slow, it can accelerate to great speeds and fly by enemy outposts, dealing large amounts of damage with its lightning and missiles."*  

| Property      | Value |
| ----------- | ----------- |
|Internal Name|`javelin-ship`|
|Health|170|
|Speed|0.11|
|Mass|2|
|Max Velocity|10|
|Item Capacity|30|
|Drill Power|-1|
|Mine Speed|100%|
|Build Speed|100%|

--- 

##### Created in <br><a href="/wiki/blocks/upgrade/javelin-ship-pad"><img id="sprlist" src="/wiki/images/block-javelin-ship-pad-small.png"/></a> 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)