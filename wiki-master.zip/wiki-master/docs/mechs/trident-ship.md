# <img id="spr" src="/wiki/images/mech-trident-ship-full.png"></img> Trident


*"A heavy bomber, built for construction and destroying enemy fortifications. Reasonably well armored."*  

| Property      | Value |
| ----------- | ----------- |
|Internal Name|`trident-ship`|
|Health|250|
|Speed|0.15|
|Mass|2.5|
|Max Velocity|10|
|Item Capacity|30|
|Drill Power|2|
|Mine Speed|100%|
|Build Speed|250%|

--- 

##### Created in <br><a href="/wiki/blocks/upgrade/trident-ship-pad"><img id="sprlist" src="/wiki/images/block-trident-ship-pad-small.png"/></a> 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)