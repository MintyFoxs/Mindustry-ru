# <img id="spr" src="/wiki/images/mech-glaive-ship-full.png"></img> Glaive


*"A large, well-armored gunship. Equipped with an incendiary repeater. Highly maneuverable."*  

| Property      | Value |
| ----------- | ----------- |
|Internal Name|`glaive-ship`|
|Health|240|
|Speed|0.32|
|Mass|3|
|Max Velocity|10|
|Item Capacity|60|
|Drill Power|4|
|Mine Speed|130%|
|Build Speed|120%|

--- 

##### Created in <br><a href="/wiki/blocks/upgrade/glaive-ship-pad"><img id="sprlist" src="/wiki/images/block-glaive-ship-pad-small.png"/></a> 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)