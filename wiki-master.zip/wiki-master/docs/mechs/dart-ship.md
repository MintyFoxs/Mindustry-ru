# <img id="spr" src="/wiki/images/mech-dart-ship-full.png"></img> Dart


*"The standard control ship. Fast mining speed. Reasonably fast and light, but has little offensive capability."*  

| Property      | Value |
| ----------- | ----------- |
|Internal Name|`dart-ship`|
|Health|200|
|Speed|0.5|
|Mass|1|
|Max Velocity|10|
|Item Capacity|30|
|Drill Power|1|
|Mine Speed|300%|
|Build Speed|110%|

--- 

[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)