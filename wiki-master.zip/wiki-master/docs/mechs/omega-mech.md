# <img id="spr" src="/wiki/images/mech-omega-mech-full.png"></img> Omega


*"A bulky and well-armored mech, made for front-line assaults. Its armor can block up to 90% of incoming damage."*  

| Property      | Value |
| ----------- | ----------- |
|Internal Name|`omega-mech`|
|Health|350|
|Speed|0.36|
|Mass|4|
|Max Velocity|10|
|Item Capacity|80|
|Drill Power|2|
|Mine Speed|150%|
|Build Speed|150%|

--- 

##### Created in <br><a href="/wiki/blocks/upgrade/omega-mech-pad"><img id="sprlist" src="/wiki/images/block-omega-mech-pad-small.png"/></a> 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)