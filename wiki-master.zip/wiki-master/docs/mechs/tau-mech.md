# <img id="spr" src="/wiki/images/mech-tau-mech-full.png"></img> Tau


*"The support mech. Heals allied blocks by shooting at them. Can heal allies in a radius with its repair ability."*  

| Property      | Value |
| ----------- | ----------- |
|Internal Name|`tau-mech`|
|Health|200|
|Speed|0.44|
|Mass|1.75|
|Max Velocity|10|
|Item Capacity|70|
|Drill Power|4|
|Mine Speed|300%|
|Build Speed|160%|

--- 

##### Created in <br><a href="/wiki/blocks/upgrade/tau-mech-pad"><img id="sprlist" src="/wiki/images/block-tau-mech-pad-small.png"/></a> 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)