# <img id="spr" src="/wiki/images/mech-delta-mech-full.png"></img> Delta


*"A fast, lightly-armored mech made for hit-and-run attacks. Does little damage against structures, but can kill large groups of enemy units very quickly with its arc lightning weapons."*  

| Property      | Value |
| ----------- | ----------- |
|Internal Name|`delta-mech`|
|Health|150|
|Speed|0.75|
|Mass|0.9|
|Max Velocity|10|
|Item Capacity|15|
|Drill Power|-1|
|Mine Speed|100%|
|Build Speed|90%|

--- 

##### Created in <br><a href="/wiki/blocks/upgrade/delta-mech-pad"><img id="sprlist" src="/wiki/images/block-delta-mech-pad-small.png"/></a> 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)