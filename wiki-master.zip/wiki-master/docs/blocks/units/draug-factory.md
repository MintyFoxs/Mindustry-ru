# <img id="spr" src="/wiki/images/block-draug-factory-large.png"></img> Draug Miner Drone Factory

*"Produces Draug mining drones."*


|General||
| --- | --- |
|Internal Name|`draug-factory`|
|Solid|No|
|Health|160    |
|Size|2x2  |
|Build Time|1.07  seconds  |
|Build Cost|<a href="/wiki/items/copper"><img id="spr" src="/wiki/images/item-copper-xlarge.png"/></a>x30 <a href="/wiki/items/lead"><img id="spr" src="/wiki/images/item-lead-xlarge.png"/></a>x70  |

|Power||
| --- | --- |
|Power Use|72  power units/second  |

|Input/Output||
| --- | --- |
|Input| |
|Production Time|41.67  seconds  |
|Max Active Units|1    |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)