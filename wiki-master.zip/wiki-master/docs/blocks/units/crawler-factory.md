# <img id="spr" src="/wiki/images/block-crawler-factory-large.png"></img> Crawler Mech Factory

*"Produces fast self-destructing swarm units."*


|General||
| --- | --- |
|Internal Name|`crawler-factory`|
|Solid|No|
|Health|160    |
|Size|2x2  |
|Build Time|0.93  seconds  |
|Build Cost|<a href="/wiki/items/lead"><img id="spr" src="/wiki/images/item-lead-xlarge.png"/></a>x45 <a href="/wiki/items/silicon"><img id="spr" src="/wiki/images/item-silicon-xlarge.png"/></a>x30  |

|Power||
| --- | --- |
|Power Use|30  power units/second  |

|Input/Output||
| --- | --- |
|Input|<a href="/wiki/items/coal"><img id="spr" src="/wiki/images/item-coal-xlarge.png"/></a>x10  |
|Production Time|5  seconds  |
|Max Active Units|6    |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)