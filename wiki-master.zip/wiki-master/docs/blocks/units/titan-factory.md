# <img id="spr" src="/wiki/images/block-titan-factory-large.png"></img> Titan Mech Factory

*"Produces advanced, armored ground units."*


|General||
| --- | --- |
|Internal Name|`titan-factory`|
|Solid|No|
|Health|360    |
|Size|3x3  |
|Build Time|2.02  seconds  |
|Build Cost|<a href="/wiki/items/lead"><img id="spr" src="/wiki/images/item-lead-xlarge.png"/></a>x50 <a href="/wiki/items/graphite"><img id="spr" src="/wiki/images/item-graphite-xlarge.png"/></a>x50 <a href="/wiki/items/silicon"><img id="spr" src="/wiki/images/item-silicon-xlarge.png"/></a>x45  |

|Power||
| --- | --- |
|Power Use|36  power units/second  |

|Input/Output||
| --- | --- |
|Input|<a href="/wiki/items/silicon"><img id="spr" src="/wiki/images/item-silicon-xlarge.png"/></a>x12  |
|Production Time|17.5  seconds  |
|Max Active Units|4    |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)