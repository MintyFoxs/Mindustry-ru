# <img id="spr" src="/wiki/images/block-spirit-factory-large.png"></img> Spirit Repair Drone Factory

*"Produces Spirit structural repair drones."*


|General||
| --- | --- |
|Internal Name|`spirit-factory`|
|Solid|No|
|Health|160    |
|Size|2x2  |
|Build Time|2.37  seconds  |
|Build Cost|<a href="/wiki/items/lead"><img id="spr" src="/wiki/images/item-lead-xlarge.png"/></a>x55 <a href="/wiki/items/metaglass"><img id="spr" src="/wiki/images/item-metaglass-xlarge.png"/></a>x45 <a href="/wiki/items/silicon"><img id="spr" src="/wiki/images/item-silicon-xlarge.png"/></a>x45  |

|Power||
| --- | --- |
|Power Use|72  power units/second  |

|Input/Output||
| --- | --- |
|Input|<a href="/wiki/items/silicon"><img id="spr" src="/wiki/images/item-silicon-xlarge.png"/></a>x30 <a href="/wiki/items/lead"><img id="spr" src="/wiki/images/item-lead-xlarge.png"/></a>x30  |
|Production Time|66.67  seconds  |
|Max Active Units|1    |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)