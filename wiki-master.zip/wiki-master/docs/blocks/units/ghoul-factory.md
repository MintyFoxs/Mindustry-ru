# <img id="spr" src="/wiki/images/block-ghoul-factory-large.png"></img> Ghoul Bomber Factory

*"Produces heavy carpet bombers."*


|General||
| --- | --- |
|Internal Name|`ghoul-factory`|
|Solid|No|
|Health|360    |
|Size|3x3  |
|Build Time|3.47  seconds  |
|Build Cost|<a href="/wiki/items/lead"><img id="spr" src="/wiki/images/item-lead-xlarge.png"/></a>x65 <a href="/wiki/items/titanium"><img id="spr" src="/wiki/images/item-titanium-xlarge.png"/></a>x75 <a href="/wiki/items/silicon"><img id="spr" src="/wiki/images/item-silicon-xlarge.png"/></a>x110  |

|Power||
| --- | --- |
|Power Use|72  power units/second  |

|Input/Output||
| --- | --- |
|Input|<a href="/wiki/items/silicon"><img id="spr" src="/wiki/images/item-silicon-xlarge.png"/></a>x15 <a href="/wiki/items/titanium"><img id="spr" src="/wiki/images/item-titanium-xlarge.png"/></a>x10  |
|Production Time|19.17  seconds  |
|Max Active Units|4    |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)