# <img id="spr" src="/wiki/images/block-fortress-factory-large.png"></img> Fortress Mech Factory

*"Produces heavy artillery ground units."*


|General||
| --- | --- |
|Internal Name|`fortress-factory`|
|Solid|No|
|Health|360    |
|Size|3x3  |
|Build Time|3.02  seconds  |
|Build Cost|<a href="/wiki/items/lead"><img id="spr" src="/wiki/images/item-lead-xlarge.png"/></a>x110 <a href="/wiki/items/thorium"><img id="spr" src="/wiki/images/item-thorium-xlarge.png"/></a>x40 <a href="/wiki/items/silicon"><img id="spr" src="/wiki/images/item-silicon-xlarge.png"/></a>x75  |

|Power||
| --- | --- |
|Power Use|84  power units/second  |

|Input/Output||
| --- | --- |
|Input|<a href="/wiki/items/silicon"><img id="spr" src="/wiki/images/item-silicon-xlarge.png"/></a>x20 <a href="/wiki/items/graphite"><img id="spr" src="/wiki/images/item-graphite-xlarge.png"/></a>x10  |
|Production Time|33.33  seconds  |
|Max Active Units|3    |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)