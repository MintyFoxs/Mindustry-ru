# <img id="spr" src="/wiki/images/block-phantom-factory-large.png"></img> Phantom Builder Drone Factory

*"Produces advanced construction drones."*


|General||
| --- | --- |
|Internal Name|`phantom-factory`|
|Solid|No|
|Health|160    |
|Size|2x2  |
|Build Time|4.09  seconds  |
|Build Cost|<a href="/wiki/items/lead"><img id="spr" src="/wiki/images/item-lead-xlarge.png"/></a>x65 <a href="/wiki/items/titanium"><img id="spr" src="/wiki/images/item-titanium-xlarge.png"/></a>x50 <a href="/wiki/items/thorium"><img id="spr" src="/wiki/images/item-thorium-xlarge.png"/></a>x60 <a href="/wiki/items/silicon"><img id="spr" src="/wiki/images/item-silicon-xlarge.png"/></a>x105  |

|Power||
| --- | --- |
|Power Use|150  power units/second  |

|Input/Output||
| --- | --- |
|Input|<a href="/wiki/items/silicon"><img id="spr" src="/wiki/images/item-silicon-xlarge.png"/></a>x50 <a href="/wiki/items/lead"><img id="spr" src="/wiki/images/item-lead-xlarge.png"/></a>x30 <a href="/wiki/items/titanium"><img id="spr" src="/wiki/images/item-titanium-xlarge.png"/></a>x20  |
|Production Time|73.33  seconds  |
|Max Active Units|1    |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)