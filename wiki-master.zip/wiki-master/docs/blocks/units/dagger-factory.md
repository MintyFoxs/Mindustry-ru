# <img id="spr" src="/wiki/images/block-dagger-factory-large.png"></img> Dagger Mech Factory

*"Produces basic ground units."*


|General||
| --- | --- |
|Internal Name|`dagger-factory`|
|Solid|No|
|Health|160    |
|Size|2x2  |
|Build Time|1.11  seconds  |
|Build Cost|<a href="/wiki/items/lead"><img id="spr" src="/wiki/images/item-lead-xlarge.png"/></a>x55 <a href="/wiki/items/silicon"><img id="spr" src="/wiki/images/item-silicon-xlarge.png"/></a>x35  |

|Power||
| --- | --- |
|Power Use|30  power units/second  |

|Input/Output||
| --- | --- |
|Input|<a href="/wiki/items/silicon"><img id="spr" src="/wiki/images/item-silicon-xlarge.png"/></a>x6  |
|Production Time|14.17  seconds  |
|Max Active Units|4    |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)