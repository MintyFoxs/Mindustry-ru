# <img id="spr" src="/wiki/images/block-repair-point-large.png"></img> Repair Point

*"Continuously heals the closest damaged unit in its vicinity."*


|General||
| --- | --- |
|Internal Name|`repair-point`|
|Solid|Yes|
|Health|40    |
|Size|1x1  |
|Build Time|0.5  seconds  |
|Build Cost|<a href="/wiki/items/copper"><img id="spr" src="/wiki/images/item-copper-xlarge.png"/></a>x15 <a href="/wiki/items/lead"><img id="spr" src="/wiki/images/item-lead-xlarge.png"/></a>x15 <a href="/wiki/items/silicon"><img id="spr" src="/wiki/images/item-silicon-xlarge.png"/></a>x15  |

|Power||
| --- | --- |
|Power Use|60  power units/second  |

|Shooting||
| --- | --- |
|Range|8.13  blocks  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)