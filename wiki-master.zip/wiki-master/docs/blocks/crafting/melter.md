# <img id="spr" src="/wiki/images/block-melter-large.png"></img> Melter

*"Melts down scrap into slag for further processing or usage in wave turrets."*


|General||
| --- | --- |
|Internal Name|`melter`|
|Solid|Yes|
|Health|200    |
|Size|1x1  |
|Build Time|1.41  seconds  |
|Build Cost|<a href="/wiki/items/copper"><img id="spr" src="/wiki/images/item-copper-xlarge.png"/></a>x30 <a href="/wiki/items/lead"><img id="spr" src="/wiki/images/item-lead-xlarge.png"/></a>x35 <a href="/wiki/items/graphite"><img id="spr" src="/wiki/images/item-graphite-xlarge.png"/></a>x45  |

|Power||
| --- | --- |
|Power Use|60  power units/second  |

|Liquids||
| --- | --- |
|Liquid Capacity|10  liquid units  |

|Items||
| --- | --- |
|Item Capacity|10  items  |

|Input/Output||
| --- | --- |
|Input|<a href="/wiki/items/scrap"><img id="spr" src="/wiki/images/item-scrap-xlarge.png"/></a>x1  |
|Output|<a href="/wiki/liquids/slag"><img id="spr" src="/wiki/images/liquid-slag.png"/></a>x2  |
|Production Time|0.17  seconds  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)