# <img id="spr" src="/wiki/images/block-blast-mixer-large.png"></img> Blast Mixer

*"Crushes and mixes clusters of spores with pyratite to produce blast compound."*


|General||
| --- | --- |
|Internal Name|`blast-mixer`|
|Solid|Yes|
|Health|60    |
|Size|2x2  |
|Build Time|0.68  seconds  |
|Build Cost|<a href="/wiki/items/lead"><img id="spr" src="/wiki/images/item-lead-xlarge.png"/></a>x30 <a href="/wiki/items/titanium"><img id="spr" src="/wiki/images/item-titanium-xlarge.png"/></a>x20  |

|Power||
| --- | --- |
|Power Use|24  power units/second  |

|Items||
| --- | --- |
|Item Capacity|10  items  |

|Input/Output||
| --- | --- |
|Input|<a href="/wiki/items/pyratite"><img id="spr" src="/wiki/images/item-pyratite-xlarge.png"/></a>x1 <a href="/wiki/items/spore-pod"><img id="spr" src="/wiki/images/item-spore-pod-xlarge.png"/></a>x1  |
|Output|<a href="/wiki/items/blast-compound"><img id="spr" src="/wiki/images/item-blast-compound-xlarge.png"/></a>x1  |
|Production Time|1.33  seconds  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)