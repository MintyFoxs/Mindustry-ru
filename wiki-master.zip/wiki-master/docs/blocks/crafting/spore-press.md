# <img id="spr" src="/wiki/images/block-spore-press-large.png"></img> Spore Press

*"Compresses spore pods under extreme pressure to synthesize oil."*


|General||
| --- | --- |
|Internal Name|`spore-press`|
|Solid|Yes|
|Health|320    |
|Size|2x2  |
|Build Time|0.81  seconds  |
|Build Cost|<a href="/wiki/items/lead"><img id="spr" src="/wiki/images/item-lead-xlarge.png"/></a>x35 <a href="/wiki/items/silicon"><img id="spr" src="/wiki/images/item-silicon-xlarge.png"/></a>x30  |

|Power||
| --- | --- |
|Power Use|36  power units/second  |

|Liquids||
| --- | --- |
|Liquid Capacity|60  liquid units  |

|Items||
| --- | --- |
|Item Capacity|10  items  |

|Input/Output||
| --- | --- |
|Input|<a href="/wiki/items/spore-pod"><img id="spr" src="/wiki/images/item-spore-pod-xlarge.png"/></a>x1  |
|Output|<a href="/wiki/liquids/oil"><img id="spr" src="/wiki/images/liquid-oil.png"/></a>x6  |
|Production Time|0.33  seconds  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)