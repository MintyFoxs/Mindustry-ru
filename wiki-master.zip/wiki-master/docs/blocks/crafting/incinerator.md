# <img id="spr" src="/wiki/images/block-incinerator-large.png"></img> Incinerator

*"Vaporizes any excess item or liquid it receives."*


|General||
| --- | --- |
|Internal Name|`incinerator`|
|Solid|Yes|
|Health|90    |
|Size|1x1  |
|Build Time|0.26  seconds  |
|Build Cost|<a href="/wiki/items/lead"><img id="spr" src="/wiki/images/item-lead-xlarge.png"/></a>x15 <a href="/wiki/items/graphite"><img id="spr" src="/wiki/images/item-graphite-xlarge.png"/></a>x5  |

|Power||
| --- | --- |
|Power Use|30  power units/second  |

|Liquids||
| --- | --- |
|Liquid Capacity|10  liquid units  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)