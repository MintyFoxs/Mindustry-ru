# <img id="spr" src="/wiki/images/block-coal-centrifuge-large.png"></img> Coal Centrifuge

*"Solidifes oil into chunks of coal."*


|General||
| --- | --- |
|Internal Name|`coal-centrifuge`|
|Solid|Yes|
|Health|60    |
|Size|2x2  |
|Build Time|1.35  seconds  |
|Build Cost|<a href="/wiki/items/lead"><img id="spr" src="/wiki/images/item-lead-xlarge.png"/></a>x30 <a href="/wiki/items/graphite"><img id="spr" src="/wiki/images/item-graphite-xlarge.png"/></a>x40 <a href="/wiki/items/titanium"><img id="spr" src="/wiki/images/item-titanium-xlarge.png"/></a>x20  |

|Power||
| --- | --- |
|Power Use|30  power units/second  |

|Liquids||
| --- | --- |
|Liquid Capacity|10  liquid units  |

|Items||
| --- | --- |
|Item Capacity|10  items  |

|Input/Output||
| --- | --- |
|Input|<a href="/wiki/liquids/oil"><img id="spr" src="/wiki/images/liquid-oil.png"/></a>x2.7  |
|Output|<a href="/wiki/items/coal"><img id="spr" src="/wiki/images/item-coal-xlarge.png"/></a>x1  |
|Production Time|0.5  seconds  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)