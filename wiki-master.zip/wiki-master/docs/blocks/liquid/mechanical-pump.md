# <img id="spr" src="/wiki/images/block-mechanical-pump-large.png"></img> Mechanical Pump

*"A cheap pump with slow output, but no power consumption."*


|General||
| --- | --- |
|Internal Name|`mechanical-pump`|
|Solid|Yes|
|Health|40    |
|Size|1x1  |
|Build Time|0.38  seconds  |
|Build Cost|<a href="/wiki/items/copper"><img id="spr" src="/wiki/images/item-copper-xlarge.png"/></a>x15 <a href="/wiki/items/metaglass"><img id="spr" src="/wiki/images/item-metaglass-xlarge.png"/></a>x10  |

|Liquids||
| --- | --- |
|Liquid Capacity|10  liquid units  |

|Input/Output||
| --- | --- |
|Output|6  liquid units/second  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)