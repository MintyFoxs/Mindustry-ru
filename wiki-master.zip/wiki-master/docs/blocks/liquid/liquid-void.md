# <img id="spr" src="/wiki/images/block-liquid-void-large.png"></img> Liquid Void

*"Removes any liquids. Sandbox only."*


|General||
| --- | --- |
|Internal Name|`liquid-void`|
|Solid|Yes|
|Health|40    |
|Size|1x1  |
|Build Time|0  seconds  |
|Build Cost| |

|Liquids||
| --- | --- |
|Liquid Capacity|10  liquid units  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)
