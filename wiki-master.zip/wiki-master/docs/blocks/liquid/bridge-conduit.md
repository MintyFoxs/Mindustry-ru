# <img id="spr" src="/wiki/images/block-bridge-conduit-large.png"></img> Bridge Conduit

*"Advanced liquid transport block. Allows transporting liquids over up to 3 tiles of any terrain or building."*


|General||
| --- | --- |
|Internal Name|`bridge-conduit`|
|Solid|Yes|
|Health|40    |
|Size|1x1  |
|Build Time|0.27  seconds  |
|Build Cost|<a href="/wiki/items/metaglass"><img id="spr" src="/wiki/images/item-metaglass-xlarge.png"/></a>x8 <a href="/wiki/items/graphite"><img id="spr" src="/wiki/images/item-graphite-xlarge.png"/></a>x4  |

|Liquids||
| --- | --- |
|Liquid Capacity|10  liquid units  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)