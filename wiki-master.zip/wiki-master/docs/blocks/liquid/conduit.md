# <img id="spr" src="/wiki/images/block-conduit-large.png"></img> Conduit

*"Basic liquid transport block. Moves liquids forward. Used in conjunction with pumps and other conduits."*


|General||
| --- | --- |
|Internal Name|`conduit`|
|Solid|No|
|Health|45    |
|Size|1x1  |
|Build Time|0.03  seconds  |
|Build Cost|<a href="/wiki/items/metaglass"><img id="spr" src="/wiki/images/item-metaglass-xlarge.png"/></a>x1  |

|Liquids||
| --- | --- |
|Liquid Capacity|10  liquid units  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)