# <img id="spr" src="/wiki/images/block-plated-conduit-large.png"></img> Plated Conduit

*"Moves liquids at the same rate as pulse conduits, but possesses more armor. Does not accept fluids from the sides by anything other than conduits.
Leaks less."*


|General||
| --- | --- |
|Internal Name|`plated-conduit`|
|Solid|No|
|Health|220    |
|Size|1x1  |
|Build Time|0.08  seconds  |
|Build Cost|<a href="/wiki/items/metaglass"><img id="spr" src="/wiki/images/item-metaglass-xlarge.png"/></a>x1 <a href="/wiki/items/thorium"><img id="spr" src="/wiki/images/item-thorium-xlarge.png"/></a>x2 <a href="/wiki/items/plastanium"><img id="spr" src="/wiki/images/item-plastanium-xlarge.png"/></a>x1  |

|Liquids||
| --- | --- |
|Liquid Capacity|16  liquid units  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)