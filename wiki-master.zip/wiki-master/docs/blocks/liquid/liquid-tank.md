# <img id="spr" src="/wiki/images/block-liquid-tank-large.png"></img> Liquid Tank

*"Stores a large amount of liquids. Use for creating buffers in situations with non-constant demand of materials or as a safeguard for cooling vital blocks."*


|General||
| --- | --- |
|Internal Name|`liquid-tank`|
|Solid|Yes|
|Health|500    |
|Size|3x3  |
|Build Time|1.04  seconds  |
|Build Cost|<a href="/wiki/items/metaglass"><img id="spr" src="/wiki/images/item-metaglass-xlarge.png"/></a>x25 <a href="/wiki/items/titanium"><img id="spr" src="/wiki/images/item-titanium-xlarge.png"/></a>x25  |

|Liquids||
| --- | --- |
|Liquid Capacity|1500  liquid units  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)