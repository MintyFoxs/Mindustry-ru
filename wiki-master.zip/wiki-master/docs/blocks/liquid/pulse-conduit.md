# <img id="spr" src="/wiki/images/block-pulse-conduit-large.png"></img> Pulse Conduit

*"An advanced liquid transport block. Transports liquids faster and stores more than standard conduits."*


|General||
| --- | --- |
|Internal Name|`pulse-conduit`|
|Solid|No|
|Health|90    |
|Size|1x1  |
|Build Time|0.06  seconds  |
|Build Cost|<a href="/wiki/items/metaglass"><img id="spr" src="/wiki/images/item-metaglass-xlarge.png"/></a>x1 <a href="/wiki/items/titanium"><img id="spr" src="/wiki/images/item-titanium-xlarge.png"/></a>x2  |

|Liquids||
| --- | --- |
|Liquid Capacity|16  liquid units  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)