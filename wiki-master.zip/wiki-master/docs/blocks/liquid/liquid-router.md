# <img id="spr" src="/wiki/images/block-liquid-router-large.png"></img> Liquid Router

*"Accepts liquids from one direction and outputs them to up to 3 other directions equally. Can also store a certain amount of liquid. Useful for splitting the liquids from one source to multiple targets."*


|General||
| --- | --- |
|Internal Name|`liquid-router`|
|Solid|Yes|
|Health|40    |
|Size|1x1  |
|Build Time|0.12  seconds  |
|Build Cost|<a href="/wiki/items/metaglass"><img id="spr" src="/wiki/images/item-metaglass-xlarge.png"/></a>x2 <a href="/wiki/items/graphite"><img id="spr" src="/wiki/images/item-graphite-xlarge.png"/></a>x4  |

|Liquids||
| --- | --- |
|Liquid Capacity|20  liquid units  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)