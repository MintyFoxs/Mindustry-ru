# <img id="spr" src="/wiki/images/block-liquid-source-large.png"></img> Liquid Source

*"Infinitely outputs liquids. Sandbox only."*


|General||
| --- | --- |
|Internal Name|`liquid-source`|
|Solid|Yes|
|Health|40    |
|Size|1x1  |
|Build Time|0  seconds  |
|Build Cost| |

|Liquids||
| --- | --- |
|Liquid Capacity|100  liquid units  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)