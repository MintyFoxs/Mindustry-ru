# <img id="spr" src="/wiki/images/block-rotary-pump-large.png"></img> Rotary Pump

*"An advanced pump. Pumps more liquid, but requires power."*


|General||
| --- | --- |
|Internal Name|`rotary-pump`|
|Solid|Yes|
|Health|160    |
|Size|2x2  |
|Build Time|2.68  seconds  |
|Build Cost|<a href="/wiki/items/copper"><img id="spr" src="/wiki/images/item-copper-xlarge.png"/></a>x70 <a href="/wiki/items/metaglass"><img id="spr" src="/wiki/images/item-metaglass-xlarge.png"/></a>x50 <a href="/wiki/items/titanium"><img id="spr" src="/wiki/images/item-titanium-xlarge.png"/></a>x35 <a href="/wiki/items/silicon"><img id="spr" src="/wiki/images/item-silicon-xlarge.png"/></a>x20  |

|Power||
| --- | --- |
|Power Use|9  power units/second  |

|Liquids||
| --- | --- |
|Liquid Capacity|30  liquid units  |

|Input/Output||
| --- | --- |
|Output|48  liquid units/second  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)