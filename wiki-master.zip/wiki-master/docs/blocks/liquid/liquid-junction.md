# <img id="spr" src="/wiki/images/block-liquid-junction-large.png"></img> Liquid Junction

*"Acts as a bridge for two crossing conduits. Useful in situations with two different conduits carrying different liquids to different locations."*


|General||
| --- | --- |
|Internal Name|`liquid-junction`|
|Solid|Yes|
|Health|40    |
|Size|1x1  |
|Build Time|0.08  seconds  |
|Build Cost|<a href="/wiki/items/metaglass"><img id="spr" src="/wiki/images/item-metaglass-xlarge.png"/></a>x2 <a href="/wiki/items/graphite"><img id="spr" src="/wiki/images/item-graphite-xlarge.png"/></a>x2  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)