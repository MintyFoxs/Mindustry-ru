# <img id="spr" src="/wiki/images/block-power-void-large.png"></img> Power Void

*"Voids all power inputted into it. Sandbox only."*


|General||
| --- | --- |
|Internal Name|`power-void`|
|Solid|Yes|
|Health|40    |
|Size|1x1  |
|Build Time|0  seconds  |
|Build Cost| |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)