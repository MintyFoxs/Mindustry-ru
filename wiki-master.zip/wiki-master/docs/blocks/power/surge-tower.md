# <img id="spr" src="/wiki/images/block-surge-tower-large.png"></img> Surge Tower

*"An extremely long-range power node with fewer available connections."*


|General||
| --- | --- |
|Internal Name|`surge-tower`|
|Solid|Yes|
|Health|160    |
|Size|2x2  |
|Build Time|0.68  seconds  |
|Build Cost|<a href="/wiki/items/lead"><img id="spr" src="/wiki/images/item-lead-xlarge.png"/></a>x10 <a href="/wiki/items/titanium"><img id="spr" src="/wiki/images/item-titanium-xlarge.png"/></a>x7 <a href="/wiki/items/silicon"><img id="spr" src="/wiki/images/item-silicon-xlarge.png"/></a>x15 <a href="/wiki/items/surge-alloy"><img id="spr" src="/wiki/images/item-surge-alloy-xlarge.png"/></a>x15  |

|Power||
| --- | --- |
|Power Range|30  blocks  |
|Max Connections|2    |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)