# <img id="spr" src="/wiki/images/block-solar-panel-large.png"></img> Solar Panel

*"Provides a small amount of power from the sun."*


|General||
| --- | --- |
|Internal Name|`solar-panel`|
|Solid|Yes|
|Health|40    |
|Size|1x1  |
|Build Time|0.32  seconds  |
|Build Cost|<a href="/wiki/items/lead"><img id="spr" src="/wiki/images/item-lead-xlarge.png"/></a>x10 <a href="/wiki/items/silicon"><img id="spr" src="/wiki/images/item-silicon-xlarge.png"/></a>x15  |

|Power||
| --- | --- |
|Base Power Generation|3.6  power units/second  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)