# <img id="spr" src="/wiki/images/block-power-node-large-large.png"></img> Large Power Node

*"An advanced power node with greater range."*


|General||
| --- | --- |
|Internal Name|`power-node-large`|
|Solid|Yes|
|Health|160    |
|Size|2x2  |
|Build Time|0.24  seconds  |
|Build Cost|<a href="/wiki/items/lead"><img id="spr" src="/wiki/images/item-lead-xlarge.png"/></a>x10 <a href="/wiki/items/titanium"><img id="spr" src="/wiki/images/item-titanium-xlarge.png"/></a>x5 <a href="/wiki/items/silicon"><img id="spr" src="/wiki/images/item-silicon-xlarge.png"/></a>x3  |

|Power||
| --- | --- |
|Power Range|9.5  blocks  |
|Max Connections|30    |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)