# <img id="spr" src="/wiki/images/block-battery-large.png"></img> Battery

*"Stores power as a buffer in times of surplus energy. Outputs power in times of deficit."*


|General||
| --- | --- |
|Internal Name|`battery`|
|Solid|Yes|
|Health|40    |
|Size|1x1  |
|Build Time|0.27  seconds  |
|Build Cost|<a href="/wiki/items/copper"><img id="spr" src="/wiki/images/item-copper-xlarge.png"/></a>x4 <a href="/wiki/items/lead"><img id="spr" src="/wiki/images/item-lead-xlarge.png"/></a>x20  |

|Power||
| --- | --- |
|Power Capacity|4000    |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)