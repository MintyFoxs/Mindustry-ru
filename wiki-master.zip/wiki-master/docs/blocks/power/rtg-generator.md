# <img id="spr" src="/wiki/images/block-rtg-generator-large.png"></img> RTG Generator

*"A simple, reliable generator. Uses the heat of decaying radioactive compounds to produce energy at a slow rate."*


|General||
| --- | --- |
|Internal Name|`rtg-generator`|
|Solid|Yes|
|Health|160    |
|Size|2x2  |
|Build Time|5.25  seconds  |
|Build Cost|<a href="/wiki/items/lead"><img id="spr" src="/wiki/images/item-lead-xlarge.png"/></a>x100 <a href="/wiki/items/thorium"><img id="spr" src="/wiki/images/item-thorium-xlarge.png"/></a>x50 <a href="/wiki/items/silicon"><img id="spr" src="/wiki/images/item-silicon-xlarge.png"/></a>x75 <a href="/wiki/items/plastanium"><img id="spr" src="/wiki/images/item-plastanium-xlarge.png"/></a>x75 <a href="/wiki/items/phase-fabric"><img id="spr" src="/wiki/images/item-phase-fabric-xlarge.png"/></a>x25  |

|Power||
| --- | --- |
|Base Power Generation|180  power units/second  |

|Items||
| --- | --- |
|Item Capacity|10  items  |

|Input/Output||
| --- | --- |
|Input|<a href="/wiki/items/thorium"><img id="spr" src="/wiki/images/item-thorium-xlarge.png"/></a> / <a href="/wiki/items/phase-fabric"><img id="spr" src="/wiki/images/item-phase-fabric-xlarge.png"/></a>  |
|Production Time|7.33  seconds  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)