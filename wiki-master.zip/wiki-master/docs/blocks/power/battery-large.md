# <img id="spr" src="/wiki/images/block-battery-large-large.png"></img> Large Battery

*"Stores much more power than a regular battery."*


|General||
| --- | --- |
|Internal Name|`battery-large`|
|Solid|Yes|
|Health|360    |
|Size|3x3  |
|Build Time|1.07  seconds  |
|Build Cost|<a href="/wiki/items/lead"><img id="spr" src="/wiki/images/item-lead-xlarge.png"/></a>x40 <a href="/wiki/items/titanium"><img id="spr" src="/wiki/images/item-titanium-xlarge.png"/></a>x20 <a href="/wiki/items/silicon"><img id="spr" src="/wiki/images/item-silicon-xlarge.png"/></a>x20  |

|Power||
| --- | --- |
|Power Capacity|50000    |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)