# <img id="spr" src="/wiki/images/block-solar-panel-large-large.png"></img> Large Solar Panel

*"A significantly more efficient version of the standard solar panel."*


|General||
| --- | --- |
|Internal Name|`solar-panel-large`|
|Solid|Yes|
|Health|360    |
|Size|3x3  |
|Build Time|3.42  seconds  |
|Build Cost|<a href="/wiki/items/lead"><img id="spr" src="/wiki/images/item-lead-xlarge.png"/></a>x100 <a href="/wiki/items/silicon"><img id="spr" src="/wiki/images/item-silicon-xlarge.png"/></a>x145 <a href="/wiki/items/phase-fabric"><img id="spr" src="/wiki/images/item-phase-fabric-xlarge.png"/></a>x15  |

|Power||
| --- | --- |
|Base Power Generation|54  power units/second  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)