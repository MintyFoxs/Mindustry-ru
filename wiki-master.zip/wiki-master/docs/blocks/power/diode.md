# <img id="spr" src="/wiki/images/block-diode-large.png"></img> Battery Diode

*"Battery power can flow through this block in only one direction, but only if the other side has less power stored."*


|General||
| --- | --- |
|Internal Name|`diode`|
|Solid|Yes|
|Health|40    |
|Size|1x1  |
|Build Time|0.49  seconds  |
|Build Cost|<a href="/wiki/items/metaglass"><img id="spr" src="/wiki/images/item-metaglass-xlarge.png"/></a>x10 <a href="/wiki/items/silicon"><img id="spr" src="/wiki/images/item-silicon-xlarge.png"/></a>x10 <a href="/wiki/items/plastanium"><img id="spr" src="/wiki/images/item-plastanium-xlarge.png"/></a>x5  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)