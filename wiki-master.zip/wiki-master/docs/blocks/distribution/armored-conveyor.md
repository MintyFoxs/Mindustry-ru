# <img id="spr" src="/wiki/images/block-armored-conveyor-large.png"></img> Armored Conveyor

*"Moves items at the same speed as titanium conveyors, but possesses more armor. Does not accept inputs from the sides from anything but other conveyor belts."*


|General||
| --- | --- |
|Internal Name|`armored-conveyor`|
|Solid|No|
|Health|180    |
|Size|1x1  |
|Build Time|0.06  seconds  |
|Build Cost|<a href="/wiki/items/metaglass"><img id="spr" src="/wiki/images/item-metaglass-xlarge.png"/></a>x1 <a href="/wiki/items/thorium"><img id="spr" src="/wiki/images/item-thorium-xlarge.png"/></a>x1 <a href="/wiki/items/plastanium"><img id="spr" src="/wiki/images/item-plastanium-xlarge.png"/></a>x1  |

|Items||
| --- | --- |
|Item Capacity|4  items  |
|Move Speed|10  items/second  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)