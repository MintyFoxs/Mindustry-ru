# <img id="spr" src="/wiki/images/block-mass-driver-large.png"></img> Mass Driver

*"The ultimate item transport block. Collects several items and then shoots them to another mass driver over a long range. Requires power to operate."*


|General||
| --- | --- |
|Internal Name|`mass-driver`|
|Solid|Yes|
|Health|360    |
|Size|3x3  |
|Build Time|5.46  seconds  |
|Build Cost|<a href="/wiki/items/lead"><img id="spr" src="/wiki/images/item-lead-xlarge.png"/></a>x125 <a href="/wiki/items/titanium"><img id="spr" src="/wiki/images/item-titanium-xlarge.png"/></a>x125 <a href="/wiki/items/thorium"><img id="spr" src="/wiki/images/item-thorium-xlarge.png"/></a>x50 <a href="/wiki/items/silicon"><img id="spr" src="/wiki/images/item-silicon-xlarge.png"/></a>x75  |

|Power||
| --- | --- |
|Power Use|105  power units/second  |

|Items||
| --- | --- |
|Item Capacity|120  items  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)