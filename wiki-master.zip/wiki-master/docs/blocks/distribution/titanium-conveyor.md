# <img id="spr" src="/wiki/images/block-titanium-conveyor-large.png"></img> Titanium Conveyor

*"Advanced item transport block. Moves items faster than standard conveyors."*


|General||
| --- | --- |
|Internal Name|`titanium-conveyor`|
|Solid|No|
|Health|65    |
|Size|1x1  |
|Build Time|0.04  seconds  |
|Build Cost|<a href="/wiki/items/copper"><img id="spr" src="/wiki/images/item-copper-xlarge.png"/></a>x1 <a href="/wiki/items/lead"><img id="spr" src="/wiki/images/item-lead-xlarge.png"/></a>x1 <a href="/wiki/items/titanium"><img id="spr" src="/wiki/images/item-titanium-xlarge.png"/></a>x1  |

|Items||
| --- | --- |
|Item Capacity|4  items  |
|Move Speed|10  items/second  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)