# <img id="spr" src="/wiki/images/block-junction-large.png"></img> Junction

*"Acts as a bridge for two crossing conveyor belts. Useful in situations with two different conveyors carrying different materials to different locations."*


|General||
| --- | --- |
|Internal Name|`junction`|
|Solid|Yes|
|Health|30    |
|Size|1x1  |
|Build Time|0.1  seconds  |
|Build Cost|<a href="/wiki/items/copper"><img id="spr" src="/wiki/images/item-copper-xlarge.png"/></a>x2  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)