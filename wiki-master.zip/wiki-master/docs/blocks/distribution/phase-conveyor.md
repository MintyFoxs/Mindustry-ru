# <img id="spr" src="/wiki/images/block-phase-conveyor-large.png"></img> Phase Conveyor

*"Advanced item transport block. Uses power to teleport items to a connected phase conveyor over several tiles."*


|General||
| --- | --- |
|Internal Name|`phase-conveyor`|
|Solid|Yes|
|Health|40    |
|Size|1x1  |
|Build Time|0.49  seconds  |
|Build Cost|<a href="/wiki/items/lead"><img id="spr" src="/wiki/images/item-lead-xlarge.png"/></a>x10 <a href="/wiki/items/graphite"><img id="spr" src="/wiki/images/item-graphite-xlarge.png"/></a>x10 <a href="/wiki/items/silicon"><img id="spr" src="/wiki/images/item-silicon-xlarge.png"/></a>x7 <a href="/wiki/items/phase-fabric"><img id="spr" src="/wiki/images/item-phase-fabric-xlarge.png"/></a>x5  |

|Power||
| --- | --- |
|Power Use|18  power units/second  |

|Items||
| --- | --- |
|Item Capacity|10  items  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)