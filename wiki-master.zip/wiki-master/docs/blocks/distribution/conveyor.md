# <img id="spr" src="/wiki/images/block-conveyor-large.png"></img> Conveyor

*"Basic item transport block. Moves items forward and automatically deposits them into blocks. Rotatable."*


|General||
| --- | --- |
|Internal Name|`conveyor`|
|Solid|No|
|Health|45    |
|Size|1x1  |
|Build Time|0.01  seconds  |
|Build Cost|<a href="/wiki/items/copper"><img id="spr" src="/wiki/images/item-copper-xlarge.png"/></a>x1  |

|Items||
| --- | --- |
|Item Capacity|4  items  |
|Move Speed|4.2  items/second  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)