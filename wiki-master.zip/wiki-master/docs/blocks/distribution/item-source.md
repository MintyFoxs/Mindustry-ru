# <img id="spr" src="/wiki/images/block-item-source-large.png"></img> Item Source

*"Infinitely outputs items. Sandbox only."*


|General||
| --- | --- |
|Internal Name|`item-source`|
|Solid|Yes|
|Health|40    |
|Size|1x1  |
|Build Time|0  seconds  |
|Build Cost| |

|Items||
| --- | --- |
|Item Capacity|10  items  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)