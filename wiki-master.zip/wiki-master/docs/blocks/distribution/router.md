# <img id="spr" src="/wiki/images/block-router-large.png"></img> Router

*"Accepts items, then outputs them to up to 3 other directions equally. Useful for splitting the materials from one source to multiple targets.

[scarlet]Never use next to production inputs, as they will get clogged by output.[]"*


|General||
| --- | --- |
|Internal Name|`router`|
|Solid|Yes|
|Health|40    |
|Size|1x1  |
|Build Time|0.05  seconds  |
|Build Cost|<a href="/wiki/items/copper"><img id="spr" src="/wiki/images/item-copper-xlarge.png"/></a>x3  |

|Items||
| --- | --- |
|Item Capacity|1  items  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)