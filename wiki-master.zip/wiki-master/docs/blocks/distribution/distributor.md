# <img id="spr" src="/wiki/images/block-distributor-large.png"></img> Distributor

*"An advanced router. Splits items to up to 7 other directions equally."*


|General||
| --- | --- |
|Internal Name|`distributor`|
|Solid|Yes|
|Health|160    |
|Size|2x2  |
|Build Time|0.08  seconds  |
|Build Cost|<a href="/wiki/items/copper"><img id="spr" src="/wiki/images/item-copper-xlarge.png"/></a>x4 <a href="/wiki/items/lead"><img id="spr" src="/wiki/images/item-lead-xlarge.png"/></a>x4  |

|Items||
| --- | --- |
|Item Capacity|1  items  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)