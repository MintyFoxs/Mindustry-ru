# <img id="spr" src="/wiki/images/block-inverted-sorter-large.png"></img> Inverted Sorter

*"Processes items like a standard sorter, but outputs selected items to the sides instead."*


|General||
| --- | --- |
|Internal Name|`inverted-sorter`|
|Solid|Yes|
|Health|40    |
|Size|1x1  |
|Build Time|0.12  seconds  |
|Build Cost|<a href="/wiki/items/copper"><img id="spr" src="/wiki/images/item-copper-xlarge.png"/></a>x2 <a href="/wiki/items/lead"><img id="spr" src="/wiki/images/item-lead-xlarge.png"/></a>x2  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)