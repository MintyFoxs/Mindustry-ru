# <img id="spr" src="/wiki/images/block-item-void-large.png"></img> Item Void

*"Destroys any items. Sandbox only."*


|General||
| --- | --- |
|Internal Name|`item-void`|
|Solid|Yes|
|Health|40    |
|Size|1x1  |
|Build Time|0  seconds  |
|Build Cost| |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)