# <img id="spr" src="/wiki/images/block-scrap-wall-gigantic-large.png"></img> Gigantic Scrap Wall



|General||
| --- | --- |
|Internal Name|`scrap-wall-gigantic`|
|Solid|Yes|
|Health|3840    |
|Size|4x4  |
|Build Time|0  seconds  |
|Build Cost| |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)