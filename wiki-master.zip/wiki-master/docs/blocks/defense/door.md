# <img id="spr" src="/wiki/images/block-door-large.png"></img> Door

*"A small door. Can be opened or closed by tapping."*


|General||
| --- | --- |
|Internal Name|`door`|
|Solid|No|
|Health|400    |
|Size|1x1  |
|Build Time|0.77  seconds  |
|Build Cost|<a href="/wiki/items/graphite"><img id="spr" src="/wiki/images/item-graphite-xlarge.png"/></a>x6 <a href="/wiki/items/silicon"><img id="spr" src="/wiki/images/item-silicon-xlarge.png"/></a>x4  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)