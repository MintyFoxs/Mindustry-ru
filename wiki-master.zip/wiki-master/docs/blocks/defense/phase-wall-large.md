# <img id="spr" src="/wiki/images/block-phase-wall-large-large.png"></img> Large Phase Wall

*"A wall coated with special phase-based reflective compound. Deflects most bullets upon impact.
Spans multiple tiles."*


|General||
| --- | --- |
|Internal Name|`phase-wall-large`|
|Solid|Yes|
|Health|2400    |
|Size|2x2  |
|Build Time|2.6  seconds  |
|Build Cost|<a href="/wiki/items/phase-fabric"><img id="spr" src="/wiki/images/item-phase-fabric-xlarge.png"/></a>x24  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)