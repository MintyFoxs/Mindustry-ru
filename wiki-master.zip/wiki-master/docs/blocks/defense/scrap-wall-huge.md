# <img id="spr" src="/wiki/images/block-scrap-wall-huge-large.png"></img> Huge Scrap Wall



|General||
| --- | --- |
|Internal Name|`scrap-wall-huge`|
|Solid|Yes|
|Health|2160    |
|Size|3x3  |
|Build Time|0  seconds  |
|Build Cost| |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)