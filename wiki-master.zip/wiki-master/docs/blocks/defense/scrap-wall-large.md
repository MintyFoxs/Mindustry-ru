# <img id="spr" src="/wiki/images/block-scrap-wall-large-large.png"></img> Large Scrap Wall



|General||
| --- | --- |
|Internal Name|`scrap-wall-large`|
|Solid|Yes|
|Health|960    |
|Size|2x2  |
|Build Time|0  seconds  |
|Build Cost| |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)