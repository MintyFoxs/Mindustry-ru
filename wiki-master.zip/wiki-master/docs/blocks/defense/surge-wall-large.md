# <img id="spr" src="/wiki/images/block-surge-wall-large-large.png"></img> Large Surge Wall

*"An extremely durable defensive block.
Builds up charge on bullet contact, releasing it randomly.
Spans multiple tiles."*


|General||
| --- | --- |
|Internal Name|`surge-wall-large`|
|Solid|Yes|
|Health|3680    |
|Size|2x2  |
|Build Time|2  seconds  |
|Build Cost|<a href="/wiki/items/surge-alloy"><img id="spr" src="/wiki/images/item-surge-alloy-xlarge.png"/></a>x24  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)