# <img id="spr" src="/wiki/images/block-surge-wall-large.png"></img> Surge Wall

*"An extremely durable defensive block.
Builds up charge on bullet contact, releasing it randomly."*


|General||
| --- | --- |
|Internal Name|`surge-wall`|
|Solid|Yes|
|Health|920    |
|Size|1x1  |
|Build Time|0.5  seconds  |
|Build Cost|<a href="/wiki/items/surge-alloy"><img id="spr" src="/wiki/images/item-surge-alloy-xlarge.png"/></a>x6  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)