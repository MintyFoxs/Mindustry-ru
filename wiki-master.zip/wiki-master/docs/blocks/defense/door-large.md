# <img id="spr" src="/wiki/images/block-door-large-large.png"></img> Large Door

*"A large door. Can be opened and closed by tapping.
Spans multiple tiles."*


|General||
| --- | --- |
|Internal Name|`door-large`|
|Solid|No|
|Health|1600    |
|Size|2x2  |
|Build Time|3.07  seconds  |
|Build Cost|<a href="/wiki/items/graphite"><img id="spr" src="/wiki/images/item-graphite-xlarge.png"/></a>x24 <a href="/wiki/items/silicon"><img id="spr" src="/wiki/images/item-silicon-xlarge.png"/></a>x16  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)