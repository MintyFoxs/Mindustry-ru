# <img id="spr" src="/wiki/images/block-copper-wall-large.png"></img> Copper Wall

*"A cheap defensive block.
Useful for protecting the core and turrets in the first few waves."*


|General||
| --- | --- |
|Internal Name|`copper-wall`|
|Solid|Yes|
|Health|320    |
|Size|1x1  |
|Build Time|0.25  seconds  |
|Build Cost|<a href="/wiki/items/copper"><img id="spr" src="/wiki/images/item-copper-xlarge.png"/></a>x6  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)