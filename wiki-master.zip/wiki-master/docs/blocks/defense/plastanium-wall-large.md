# <img id="spr" src="/wiki/images/block-plastanium-wall-large-large.png"></img> Large Plastanium Wall

*"A special type of wall that absorbs electric arcs and blocks automatic power node connections.
Spans multiple tiles."*


|General||
| --- | --- |
|Internal Name|`plastanium-wall-large`|
|Solid|Yes|
|Health|3040    |
|Size|2x2  |
|Build Time|3.17  seconds  |
|Build Cost|<a href="/wiki/items/metaglass"><img id="spr" src="/wiki/images/item-metaglass-xlarge.png"/></a>x8 <a href="/wiki/items/plastanium"><img id="spr" src="/wiki/images/item-plastanium-xlarge.png"/></a>x20  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)