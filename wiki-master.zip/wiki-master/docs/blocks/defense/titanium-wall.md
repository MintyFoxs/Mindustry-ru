# <img id="spr" src="/wiki/images/block-titanium-wall-large.png"></img> Titanium Wall

*"A moderately strong defensive block.
Provides moderate protection from enemies."*


|General||
| --- | --- |
|Internal Name|`titanium-wall`|
|Solid|Yes|
|Health|440    |
|Size|1x1  |
|Build Time|0.5  seconds  |
|Build Cost|<a href="/wiki/items/titanium"><img id="spr" src="/wiki/images/item-titanium-xlarge.png"/></a>x6  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)