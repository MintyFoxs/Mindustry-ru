# <img id="spr" src="/wiki/images/block-phase-wall-large.png"></img> Phase Wall

*"A wall coated with special phase-based reflective compound. Deflects most bullets upon impact."*


|General||
| --- | --- |
|Internal Name|`phase-wall`|
|Solid|Yes|
|Health|600    |
|Size|1x1  |
|Build Time|0.65  seconds  |
|Build Cost|<a href="/wiki/items/phase-fabric"><img id="spr" src="/wiki/images/item-phase-fabric-xlarge.png"/></a>x6  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)