# <img id="spr" src="/wiki/images/block-thorium-wall-large.png"></img> Thorium Wall

*"A strong defensive block.
Decent protection from enemies."*


|General||
| --- | --- |
|Internal Name|`thorium-wall`|
|Solid|Yes|
|Health|800    |
|Size|1x1  |
|Build Time|0.55  seconds  |
|Build Cost|<a href="/wiki/items/thorium"><img id="spr" src="/wiki/images/item-thorium-xlarge.png"/></a>x6  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)