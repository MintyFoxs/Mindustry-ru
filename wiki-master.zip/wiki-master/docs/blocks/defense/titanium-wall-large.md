# <img id="spr" src="/wiki/images/block-titanium-wall-large-large.png"></img> Large Titanium Wall

*"A moderately strong defensive block.
Provides moderate protection from enemies.
Spans multiple tiles."*


|General||
| --- | --- |
|Internal Name|`titanium-wall-large`|
|Solid|Yes|
|Health|1760    |
|Size|2x2  |
|Build Time|2  seconds  |
|Build Cost|<a href="/wiki/items/titanium"><img id="spr" src="/wiki/images/item-titanium-xlarge.png"/></a>x24  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)