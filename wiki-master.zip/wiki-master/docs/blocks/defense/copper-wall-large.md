# <img id="spr" src="/wiki/images/block-copper-wall-large-large.png"></img> Large Copper Wall

*"A cheap defensive block.
Useful for protecting the core and turrets in the first few waves.
Spans multiple tiles."*


|General||
| --- | --- |
|Internal Name|`copper-wall-large`|
|Solid|Yes|
|Health|1280    |
|Size|2x2  |
|Build Time|1  seconds  |
|Build Cost|<a href="/wiki/items/copper"><img id="spr" src="/wiki/images/item-copper-xlarge.png"/></a>x24  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)