# <img id="spr" src="/wiki/images/block-scrap-wall-large.png"></img> Scrap Wall



|General||
| --- | --- |
|Internal Name|`scrap-wall`|
|Solid|Yes|
|Health|240    |
|Size|1x1  |
|Build Time|0  seconds  |
|Build Cost| |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)