# <img id="spr" src="/wiki/images/block-plastanium-wall-large.png"></img> Plastanium Wall

*"A special type of wall that absorbs electric arcs and blocks automatic power node connections."*


|General||
| --- | --- |
|Internal Name|`plastanium-wall`|
|Solid|Yes|
|Health|760    |
|Size|1x1  |
|Build Time|0.79  seconds  |
|Build Cost|<a href="/wiki/items/metaglass"><img id="spr" src="/wiki/images/item-metaglass-xlarge.png"/></a>x2 <a href="/wiki/items/plastanium"><img id="spr" src="/wiki/images/item-plastanium-xlarge.png"/></a>x5  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)