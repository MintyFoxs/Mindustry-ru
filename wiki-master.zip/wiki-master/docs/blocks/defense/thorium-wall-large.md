# <img id="spr" src="/wiki/images/block-thorium-wall-large-large.png"></img> Large Thorium Wall

*"A strong defensive block.
Decent protection from enemies.
Spans multiple tiles."*


|General||
| --- | --- |
|Internal Name|`thorium-wall-large`|
|Solid|Yes|
|Health|3200    |
|Size|2x2  |
|Build Time|2.2  seconds  |
|Build Cost|<a href="/wiki/items/thorium"><img id="spr" src="/wiki/images/item-thorium-xlarge.png"/></a>x24  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)