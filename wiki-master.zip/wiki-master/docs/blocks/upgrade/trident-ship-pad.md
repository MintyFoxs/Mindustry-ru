# <img id="spr" src="/wiki/images/block-trident-ship-pad-large.png"></img> Trident Ship Pad

*"Provides transformation into a heavy support bomber.
Use by tapping while standing on it."*


|General||
| --- | --- |
|Internal Name|`trident-ship-pad`|
|Solid|No|
|Health|160    |
|Size|2x2  |
|Build Time|8.83  seconds  |
|Build Cost|<a href="/wiki/items/copper"><img id="spr" src="/wiki/images/item-copper-xlarge.png"/></a>x125 <a href="/wiki/items/lead"><img id="spr" src="/wiki/images/item-lead-xlarge.png"/></a>x125 <a href="/wiki/items/titanium"><img id="spr" src="/wiki/images/item-titanium-xlarge.png"/></a>x150 <a href="/wiki/items/silicon"><img id="spr" src="/wiki/images/item-silicon-xlarge.png"/></a>x125 <a href="/wiki/items/plastanium"><img id="spr" src="/wiki/images/item-plastanium-xlarge.png"/></a>x100  |

|Power||
| --- | --- |
|Power Use|60  power units/second  |

|Input/Output||
| --- | --- |
|Production Time|5  seconds  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)