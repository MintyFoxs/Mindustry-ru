# <img id="spr" src="/wiki/images/block-javelin-ship-pad-large.png"></img> Javelin Ship Pad

*"Provides transformation into a quick, lightly-armored interceptor.
Use by tapping while standing on it."*


|General||
| --- | --- |
|Internal Name|`javelin-ship-pad`|
|Solid|No|
|Health|160    |
|Size|2x2  |
|Build Time|15.71  seconds  |
|Build Cost|<a href="/wiki/items/lead"><img id="spr" src="/wiki/images/item-lead-xlarge.png"/></a>x175 <a href="/wiki/items/titanium"><img id="spr" src="/wiki/images/item-titanium-xlarge.png"/></a>x250 <a href="/wiki/items/silicon"><img id="spr" src="/wiki/images/item-silicon-xlarge.png"/></a>x225 <a href="/wiki/items/plastanium"><img id="spr" src="/wiki/images/item-plastanium-xlarge.png"/></a>x200 <a href="/wiki/items/phase-fabric"><img id="spr" src="/wiki/images/item-phase-fabric-xlarge.png"/></a>x100  |

|Power||
| --- | --- |
|Power Use|48  power units/second  |

|Input/Output||
| --- | --- |
|Production Time|5  seconds  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)