# <img id="spr" src="/wiki/images/block-omega-mech-pad-large.png"></img> Omega Mech Pad

*"Provides transformation into a heavily-armored missile mech.
Use by tapping while standing on it."*


|General||
| --- | --- |
|Internal Name|`omega-mech-pad`|
|Solid|No|
|Health|360    |
|Size|3x3  |
|Build Time|19.04  seconds  |
|Build Cost|<a href="/wiki/items/lead"><img id="spr" src="/wiki/images/item-lead-xlarge.png"/></a>x225 <a href="/wiki/items/graphite"><img id="spr" src="/wiki/images/item-graphite-xlarge.png"/></a>x275 <a href="/wiki/items/thorium"><img id="spr" src="/wiki/images/item-thorium-xlarge.png"/></a>x300 <a href="/wiki/items/silicon"><img id="spr" src="/wiki/images/item-silicon-xlarge.png"/></a>x325 <a href="/wiki/items/surge-alloy"><img id="spr" src="/wiki/images/item-surge-alloy-xlarge.png"/></a>x120  |

|Power||
| --- | --- |
|Power Use|72  power units/second  |

|Input/Output||
| --- | --- |
|Production Time|5  seconds  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)