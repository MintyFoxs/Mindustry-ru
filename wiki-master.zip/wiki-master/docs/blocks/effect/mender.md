# <img id="spr" src="/wiki/images/block-mender-large.png"></img> Mender

*"Periodically repairs blocks in its vicinity. Keeps defenses repaired in-between waves.
Optionally uses silicon to boost range and efficiency."*


|General||
| --- | --- |
|Internal Name|`mender`|
|Solid|Yes|
|Health|80    |
|Size|1x1  |
|Build Time|0.56  seconds  |
|Build Cost|<a href="/wiki/items/copper"><img id="spr" src="/wiki/images/item-copper-xlarge.png"/></a>x25 <a href="/wiki/items/lead"><img id="spr" src="/wiki/images/item-lead-xlarge.png"/></a>x30  |

|Power||
| --- | --- |
|Power Use|18  power units/second  |

|Items||
| --- | --- |
|Item Capacity|10  items  |

|Shooting||
| --- | --- |
|Block Full Repair Time|83  seconds  |
|Range|5  blocks  |

|Optional Enhancements||
| --- | --- |
|Booster|<a href="/wiki/items/silicon"><img id="spr" src="/wiki/images/item-silicon-xlarge.png"/></a>x1  |
|Boost Effect|2.5  blocks  2 x speed  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)