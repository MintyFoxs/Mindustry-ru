# <img id="spr" src="/wiki/images/block-unloader-large.png"></img> Unloader

*"Unloads items from any nearby non-transportation block. The type of item to be unloaded can be changed by tapping."*


|General||
| --- | --- |
|Internal Name|`unloader`|
|Solid|Yes|
|Health|70    |
|Size|1x1  |
|Build Time|0.82  seconds  |
|Build Cost|<a href="/wiki/items/titanium"><img id="spr" src="/wiki/images/item-titanium-xlarge.png"/></a>x25 <a href="/wiki/items/silicon"><img id="spr" src="/wiki/images/item-silicon-xlarge.png"/></a>x30  |

|Items||
| --- | --- |
|Item Capacity|10  items  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)