# <img id="spr" src="/wiki/images/block-vault-large.png"></img> Vault

*"Stores a large amount of items of each type. An unloader block can be used to retrieve items from the vault."*


|General||
| --- | --- |
|Internal Name|`vault`|
|Solid|Yes|
|Health|360    |
|Size|3x3  |
|Build Time|6.46  seconds  |
|Build Cost|<a href="/wiki/items/titanium"><img id="spr" src="/wiki/images/item-titanium-xlarge.png"/></a>x250 <a href="/wiki/items/thorium"><img id="spr" src="/wiki/images/item-thorium-xlarge.png"/></a>x125  |

|Items||
| --- | --- |
|Item Capacity|1000  items  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)