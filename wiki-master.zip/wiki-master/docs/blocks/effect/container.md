# <img id="spr" src="/wiki/images/block-container-large.png"></img> Container

*"Stores a small amount of items of each type. An unloader block can be used to retrieve items from the container."*


|General||
| --- | --- |
|Internal Name|`container`|
|Solid|Yes|
|Health|160    |
|Size|2x2  |
|Build Time|1.67  seconds  |
|Build Cost|<a href="/wiki/items/titanium"><img id="spr" src="/wiki/images/item-titanium-xlarge.png"/></a>x100  |

|Items||
| --- | --- |
|Item Capacity|300  items  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)