# <img id="spr" src="/wiki/images/block-illuminator-large.png"></img> Illuminator

*"A small, compact, configurable light source. Requires power to function."*


|General||
| --- | --- |
|Internal Name|`illuminator`|
|Solid|No|
|Health|40    |
|Size|1x1  |
|Build Time|0.09  seconds  |
|Build Cost|<a href="/wiki/items/graphite"><img id="spr" src="/wiki/images/item-graphite-xlarge.png"/></a>x4 <a href="/wiki/items/silicon"><img id="spr" src="/wiki/images/item-silicon-xlarge.png"/></a>x2  |

|Power||
| --- | --- |
|Power Use|3  power units/second  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)