# <img id="spr" src="/wiki/images/block-launch-pad-large-large.png"></img> Large Launch Pad

*"An improved version of the launch pad. Stores more items. Launches more frequently."*


|General||
| --- | --- |
|Internal Name|`launch-pad-large`|
|Solid|Yes|
|Health|640    |
|Size|4x4  |
|Build Time|9.88  seconds  |
|Build Cost|<a href="/wiki/items/lead"><img id="spr" src="/wiki/images/item-lead-xlarge.png"/></a>x250 <a href="/wiki/items/titanium"><img id="spr" src="/wiki/images/item-titanium-xlarge.png"/></a>x200 <a href="/wiki/items/silicon"><img id="spr" src="/wiki/images/item-silicon-xlarge.png"/></a>x150 <a href="/wiki/items/plastanium"><img id="spr" src="/wiki/images/item-plastanium-xlarge.png"/></a>x75  |

|Power||
| --- | --- |
|Power Use|120  power units/second  |

|Items||
| --- | --- |
|Item Capacity|250  items  |
|Time Between Launches|14  seconds  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)