# <img id="spr" src="/wiki/images/block-message-large.png"></img> Message

*"Stores a message. Used for communication between allies."*


|General||
| --- | --- |
|Internal Name|`message`|
|Solid|Yes|
|Health|40    |
|Size|1x1  |
|Build Time|0.08  seconds  |
|Build Cost|<a href="/wiki/items/graphite"><img id="spr" src="/wiki/images/item-graphite-xlarge.png"/></a>x5  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)