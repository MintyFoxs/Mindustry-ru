# <img id="spr" src="/wiki/images/core-shard-icon-large.png"></img> Core: Shard 

*"The first iteration of the core capsule. Once destroyed, all contact to the region is lost. Do not let this happen."*


|General||
| --- | --- |
|Internal Name|`core-shard`|
|Solid|Yes|
|Health|1100    |
|Size|3x3  |
|Build Time|16.67  seconds  |
|Build Cost|<a href="/wiki/items/titanium"><img id="spr" src="/wiki/images/item-titanium-xlarge.png"/></a>x1000  |

|Items||
| --- | --- |
|Item Capacity|4000  items  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)