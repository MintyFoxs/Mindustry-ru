# <img id="spr" src="/wiki/images/core-nucleus-icon-large.png"></img> Core: Nucleus 

*"The third and final iteration of the core capsule. Extremely well armored. Stores massive amounts of resources."*


|General||
| --- | --- |
|Internal Name|`core-nucleus`|
|Solid|Yes|
|Health|4000    |
|Size|5x5  |
|Build Time|110  seconds  |
|Build Cost|<a href="/wiki/items/titanium"><img id="spr" src="/wiki/images/item-titanium-xlarge.png"/></a>x4000 <a href="/wiki/items/silicon"><img id="spr" src="/wiki/images/item-silicon-xlarge.png"/></a>x2000 <a href="/wiki/items/surge-alloy"><img id="spr" src="/wiki/images/item-surge-alloy-xlarge.png"/></a>x1000  |

|Items||
| --- | --- |
|Item Capacity|13000  items  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)