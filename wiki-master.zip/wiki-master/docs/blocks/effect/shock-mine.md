# <img id="spr" src="/wiki/images/block-shock-mine-large.png"></img> Shock Mine

*"Damages enemies stepping on the mine. Nearly invisible to the enemy."*


|General||
| --- | --- |
|Internal Name|`shock-mine`|
|Solid|No|
|Health|40    |
|Size|1x1  |
|Build Time|0.45  seconds  |
|Build Cost|<a href="/wiki/items/lead"><img id="spr" src="/wiki/images/item-lead-xlarge.png"/></a>x25 <a href="/wiki/items/silicon"><img id="spr" src="/wiki/images/item-silicon-xlarge.png"/></a>x12  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)