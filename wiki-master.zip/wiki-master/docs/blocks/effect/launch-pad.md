# <img id="spr" src="/wiki/images/block-launch-pad-large.png"></img> Launch Pad

*"Launches batches of items without any need for a core launch."*


|General||
| --- | --- |
|Internal Name|`launch-pad`|
|Solid|Yes|
|Health|360    |
|Size|3x3  |
|Build Time|4.25  seconds  |
|Build Cost|<a href="/wiki/items/copper"><img id="spr" src="/wiki/images/item-copper-xlarge.png"/></a>x250 <a href="/wiki/items/lead"><img id="spr" src="/wiki/images/item-lead-xlarge.png"/></a>x100 <a href="/wiki/items/silicon"><img id="spr" src="/wiki/images/item-silicon-xlarge.png"/></a>x75  |

|Power||
| --- | --- |
|Power Use|60  power units/second  |

|Items||
| --- | --- |
|Item Capacity|100  items  |
|Time Between Launches|16  seconds  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)