# <img id="spr" src="/wiki/images/core-foundation-icon-large.png"></img> Core: Foundation 

*"The second version of the core. Better armored. Stores more resources."*


|General||
| --- | --- |
|Internal Name|`core-foundation`|
|Solid|Yes|
|Health|2000    |
|Size|4x4  |
|Build Time|38.33  seconds  |
|Build Cost|<a href="/wiki/items/titanium"><img id="spr" src="/wiki/images/item-titanium-xlarge.png"/></a>x1500 <a href="/wiki/items/silicon"><img id="spr" src="/wiki/images/item-silicon-xlarge.png"/></a>x1000  |

|Items||
| --- | --- |
|Item Capacity|9000  items  |


--- 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)