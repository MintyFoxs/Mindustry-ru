# <img id="spr" src="/wiki/images/dagger.png"></img> Dagger 


*"The most basic ground mech. Cheap to produce. Overwhelming when used in swarms."*  

| Property      | Value |
| ----------- | ----------- |
|Internal Name|`dagger`|
|Health|130|
|Speed|0.2|
|Mass|1.75|
|Max Velocity|1.1|

--- 

##### Created in <br><a href="/wiki/blocks/units/dagger-factory"><img id="sprlist" src="/wiki/images/block-dagger-factory-small.png"/></a> 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)