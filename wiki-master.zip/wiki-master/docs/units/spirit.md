# <img id="spr" src="/wiki/images/spirit.png"></img> Spirit Repair Drone 


*"A modified draug drone, designed for repair instead of mining. Automatically fixes any damaged blocks in the area."*  

| Property      | Value |
| ----------- | ----------- |
|Internal Name|`spirit`|
|Health|100|
|Speed|0.42|
|Mass|1|
|Max Velocity|1.6|

--- 

##### Created in <br><a href="/wiki/blocks/units/spirit-factory"><img id="sprlist" src="/wiki/images/block-spirit-factory-small.png"/></a> 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)