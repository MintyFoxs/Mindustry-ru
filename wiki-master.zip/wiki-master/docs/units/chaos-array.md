# <img id="spr" src="/wiki/images/chaos-array.png"></img> Chaos Array 


*"Unknown..."*  

| Property      | Value |
| ----------- | ----------- |
|Internal Name|`chaos-array`|
|Health|3000|
|Speed|0.12|
|Mass|5|
|Max Velocity|0.68|

--- 

[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)