# <img id="spr" src="/wiki/images/fortress.png"></img> Fortress 


*"A heavy artillery mech. Equipped with two modified Hail-type cannons for long-range assault on enemy structures and units."*  

| Property      | Value |
| ----------- | ----------- |
|Internal Name|`fortress`|
|Health|750|
|Speed|0.15|
|Mass|5|
|Max Velocity|0.78|

--- 

##### Created in <br><a href="/wiki/blocks/units/fortress-factory"><img id="sprlist" src="/wiki/images/block-fortress-factory-small.png"/></a> 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)