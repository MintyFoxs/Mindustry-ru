# <img id="spr" src="/wiki/images/ghoul.png"></img> Ghoul Bomber 


*"A heavy carpet bomber. Rips through enemy structures, targeting critical infrastructure."*  

| Property      | Value |
| ----------- | ----------- |
|Internal Name|`ghoul`|
|Health|220|
|Speed|0.2|
|Mass|3|
|Max Velocity|1.4|

--- 

##### Created in <br><a href="/wiki/blocks/units/ghoul-factory"><img id="sprlist" src="/wiki/images/block-ghoul-factory-small.png"/></a> 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)