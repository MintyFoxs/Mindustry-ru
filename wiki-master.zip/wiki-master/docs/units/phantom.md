# <img id="spr" src="/wiki/images/phantom.png"></img> Phantom Builder Drone 


*"An advanced drone unit. Follows users. Assists in block construction."*  

| Property      | Value |
| ----------- | ----------- |
|Internal Name|`phantom`|
|Health|400|
|Speed|0.45|
|Mass|2|
|Max Velocity|1.9|

--- 

##### Created in <br><a href="/wiki/blocks/units/phantom-factory"><img id="sprlist" src="/wiki/images/block-phantom-factory-small.png"/></a> 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)