# <img id="spr" src="/wiki/images/wraith.png"></img> Wraith Fighter 


*"A fast, hit-and-run interceptor unit. Targets power generators."*  

| Property      | Value |
| ----------- | ----------- |
|Internal Name|`wraith`|
|Health|75|
|Speed|0.3|
|Mass|1.5|
|Max Velocity|1.9|

--- 

##### Created in <br><a href="/wiki/blocks/units/wraith-factory"><img id="sprlist" src="/wiki/images/block-wraith-factory-small.png"/></a> 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)