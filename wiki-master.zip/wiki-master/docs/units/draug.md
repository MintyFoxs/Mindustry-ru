# <img id="spr" src="/wiki/images/draug.png"></img> Draug Miner Drone 


*"A primitive mining drone. Cheap to produce. Expendable. Automatically mines copper and lead in the vicinity. Delivers mined resources to the closest core."*  

| Property      | Value |
| ----------- | ----------- |
|Internal Name|`draug`|
|Health|80|
|Speed|0.3|
|Mass|1|
|Max Velocity|1.2|

--- 

##### Created in <br><a href="/wiki/blocks/units/draug-factory"><img id="sprlist" src="/wiki/images/block-draug-factory-small.png"/></a> 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)