# <img id="spr" src="/wiki/images/eradicator.png"></img> Eradicator 


*"Unknown..."*  

| Property      | Value |
| ----------- | ----------- |
|Internal Name|`eradicator`|
|Health|9000|
|Speed|0.12|
|Mass|5|
|Max Velocity|0.68|

--- 

[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)