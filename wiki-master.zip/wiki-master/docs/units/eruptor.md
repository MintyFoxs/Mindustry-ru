# <img id="spr" src="/wiki/images/eruptor.png"></img> Eruptor 


*"A heavy mech designed to take down structures. Fires a stream of slag at enemy fortifications, melting them and setting volatiles on fire."*  

| Property      | Value |
| ----------- | ----------- |
|Internal Name|`eruptor`|
|Health|600|
|Speed|0.16|
|Mass|5|
|Max Velocity|0.81|

--- 

[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)