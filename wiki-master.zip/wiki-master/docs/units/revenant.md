# <img id="spr" src="/wiki/images/revenant.png"></img> Revenant 


*"A heavy, hovering missile array."*  

| Property      | Value |
| ----------- | ----------- |
|Internal Name|`revenant`|
|Health|1000|
|Speed|0.1|
|Mass|5|
|Max Velocity|1|

--- 

##### Created in <br><a href="/wiki/blocks/units/revenant-factory"><img id="sprlist" src="/wiki/images/block-revenant-factory-small.png"/></a> 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)