# <img id="spr" src="/wiki/images/titan.png"></img> Titan 


*"An advanced, armored ground unit. Attacks both ground and air targets. Equipped with two miniature Scorch-class flamethrowers."*  

| Property      | Value |
| ----------- | ----------- |
|Internal Name|`titan`|
|Health|460|
|Speed|0.22|
|Mass|3.5|
|Max Velocity|0.8|

--- 

##### Created in <br><a href="/wiki/blocks/units/titan-factory"><img id="sprlist" src="/wiki/images/block-titan-factory-small.png"/></a> 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)