# <img id="spr" src="/wiki/images/reaper.png"></img> Reaper 


*"Unknown..."*  

| Property      | Value |
| ----------- | ----------- |
|Internal Name|`reaper`|
|Health|11000|
|Speed|0.01|
|Mass|30|
|Max Velocity|0.6|

--- 

[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)