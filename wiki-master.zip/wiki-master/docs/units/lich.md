# <img id="spr" src="/wiki/images/lich.png"></img> Lich 


*"Unknown..."*  

| Property      | Value |
| ----------- | ----------- |
|Internal Name|`lich`|
|Health|6000|
|Speed|0.01|
|Mass|20|
|Max Velocity|0.6|

--- 

[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)