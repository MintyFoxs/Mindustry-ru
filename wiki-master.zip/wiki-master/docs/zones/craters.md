# <img id="zonespr" src="/wiki/images/zone-craters.png"></img> The Craters 

<img id="zone" src="/wiki/images/zone-craters.png"></img>

"Water has accumulated in this crater, relic of the old wars. Reclaim the area. Collect sand. Smelt metaglass. Pump water to cool turrets and drills."

| Property      | Value |
| ----------- | ----------- |
|Internal Name|`craters`|
|Mode|Survival|
|Launch Wave|10|
|Launch Period|10|
|Starting Loadout|<a href="/wiki/items/copper"><img id="spr" src="/wiki/images/item-copper-xlarge.png"/></a>x100 |
|Resources|<a href="/wiki/items/copper"><img id="sprlist" src="/wiki/images/item-copper-xlarge.png"/></a> <a href="/wiki/items/lead"><img id="sprlist" src="/wiki/images/item-lead-xlarge.png"/></a> <a href="/wiki/items/sand"><img id="sprlist" src="/wiki/images/item-sand-xlarge.png"/></a> <a href="/wiki/items/coal"><img id="sprlist" src="/wiki/images/item-coal-xlarge.png"/></a> <a href="/wiki/items/scrap"><img id="sprlist" src="/wiki/images/item-scrap-xlarge.png"/></a> |

--- 

##### Preceded by <br><a href="/wiki/zones/frozenForest"><img id="zonespr" src="/wiki/images/zone-frozenForest.png"/></a> 

##### Required for <br><a href="/wiki/zones/ruinousShores"><img id="zonespr" src="/wiki/images/zone-ruinousShores.png"/></a> <a href="/wiki/zones/overgrowth"><img id="zonespr" src="/wiki/images/zone-overgrowth.png"/></a> 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)