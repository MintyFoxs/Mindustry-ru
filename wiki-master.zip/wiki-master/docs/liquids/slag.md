# <img id="spr" src="/wiki/images/liquid-slag.png"></img> Slag 


| Property      | Value |
| ----------- | ----------- |
|Internal Name|`slag`|
|Flammability|0%|
|Explosiveness|0%|
|Heat Capacity|50%|

*"Various different types of molten metal mixed together. Can be separated into its constituent minerals, or sprayed at enemy units as a weapon."*

--- 

##### Produced in <br><a href="/wiki/blocks/crafting/melter"><img id="sprlist" src="/wiki/images/block-melter-small.png"/></a> 

##### Required for <br><a href="/wiki/blocks/crafting/separator"><img id="sprlist" src="/wiki/images/block-separator-small.png"/></a> <a href="/wiki/blocks/turret/wave"><img id="sprlist" src="/wiki/images/block-wave-small.png"/></a> 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)