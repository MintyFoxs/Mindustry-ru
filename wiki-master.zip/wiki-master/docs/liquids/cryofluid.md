# <img id="spr" src="/wiki/images/liquid-cryofluid.png"></img> Cryofluid 


| Property      | Value |
| ----------- | ----------- |
|Internal Name|`cryofluid`|
|Flammability|0%|
|Explosiveness|0%|
|Heat Capacity|90%|

*"An inert, non-corrosive liquid created from water and titanium. Has extremely high heat capacity. Extensively used as coolant."*

--- 

##### Produced in <br><a href="/wiki/blocks/crafting/cryofluidmixer"><img id="sprlist" src="/wiki/images/block-cryofluidmixer-small.png"/></a> 

##### Required for <br><a href="/wiki/blocks/effect/force-projector"><img id="sprlist" src="/wiki/images/block-force-projector-small.png"/></a> <a href="/wiki/blocks/power/differential-generator"><img id="sprlist" src="/wiki/images/block-differential-generator-small.png"/></a> <a href="/wiki/blocks/power/thorium-reactor"><img id="sprlist" src="/wiki/images/block-thorium-reactor-small.png"/></a> <a href="/wiki/blocks/power/impact-reactor"><img id="sprlist" src="/wiki/images/block-impact-reactor-small.png"/></a> <a href="/wiki/blocks/turret/duo"><img id="sprlist" src="/wiki/images/block-duo-small.png"/></a> <a href="/wiki/blocks/turret/scatter"><img id="sprlist" src="/wiki/images/block-scatter-small.png"/></a> <a href="/wiki/blocks/turret/scorch"><img id="sprlist" src="/wiki/images/block-scorch-small.png"/></a> <a href="/wiki/blocks/turret/hail"><img id="sprlist" src="/wiki/images/block-hail-small.png"/></a> <a href="/wiki/blocks/turret/wave"><img id="sprlist" src="/wiki/images/block-wave-small.png"/></a> <a href="/wiki/blocks/turret/lancer"><img id="sprlist" src="/wiki/images/block-lancer-small.png"/></a> <a href="/wiki/blocks/turret/arc"><img id="sprlist" src="/wiki/images/block-arc-small.png"/></a> <a href="/wiki/blocks/turret/swarmer"><img id="sprlist" src="/wiki/images/block-swarmer-small.png"/></a> <a href="/wiki/blocks/turret/salvo"><img id="sprlist" src="/wiki/images/block-salvo-small.png"/></a> <a href="/wiki/blocks/turret/fuse"><img id="sprlist" src="/wiki/images/block-fuse-small.png"/></a> <a href="/wiki/blocks/turret/ripple"><img id="sprlist" src="/wiki/images/block-ripple-small.png"/></a> <a href="/wiki/blocks/turret/cyclone"><img id="sprlist" src="/wiki/images/block-cyclone-small.png"/></a> <a href="/wiki/blocks/turret/spectre"><img id="sprlist" src="/wiki/images/block-spectre-small.png"/></a> <a href="/wiki/blocks/turret/meltdown"><img id="sprlist" src="/wiki/images/block-meltdown-small.png"/></a> 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)