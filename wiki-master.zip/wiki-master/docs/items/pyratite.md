# <img id="spr" src="/wiki/images/item-pyratite.png"></img> Pyratite 


*"An extremely flammable substance used in incendiary weapons."*  

| Property      | Value |
| ----------- | ----------- |
|Internal Name|`pyratite`|
|Color|`ffaa5f`|
|Type|Resource|
|Flammability|140%|
|Explosiveness|40%|
|Radioactivity|0%|
|Naturally Occurring|No|
|Hardness|0|

--- 

##### Produced in <br><a href="/wiki/blocks/crafting/pyratite-mixer"><img id="sprlist" src="/wiki/images/block-pyratite-mixer-small.png"/></a> 

##### Required for <br><a href="/wiki/blocks/crafting/blast-mixer"><img id="sprlist" src="/wiki/images/block-blast-mixer-small.png"/></a> <a href="/wiki/blocks/power/combustion-generator"><img id="sprlist" src="/wiki/images/block-combustion-generator-small.png"/></a> <a href="/wiki/blocks/power/turbine-generator"><img id="sprlist" src="/wiki/images/block-turbine-generator-small.png"/></a> <a href="/wiki/blocks/power/differential-generator"><img id="sprlist" src="/wiki/images/block-differential-generator-small.png"/></a> <a href="/wiki/blocks/turret/duo"><img id="sprlist" src="/wiki/images/block-duo-small.png"/></a> <a href="/wiki/blocks/turret/scorch"><img id="sprlist" src="/wiki/images/block-scorch-small.png"/></a> <a href="/wiki/blocks/turret/hail"><img id="sprlist" src="/wiki/images/block-hail-small.png"/></a> <a href="/wiki/blocks/turret/swarmer"><img id="sprlist" src="/wiki/images/block-swarmer-small.png"/></a> <a href="/wiki/blocks/turret/salvo"><img id="sprlist" src="/wiki/images/block-salvo-small.png"/></a> <a href="/wiki/blocks/turret/ripple"><img id="sprlist" src="/wiki/images/block-ripple-small.png"/></a> <a href="/wiki/blocks/turret/spectre"><img id="sprlist" src="/wiki/images/block-spectre-small.png"/></a> 

[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)