# <img id="spr" src="/wiki/images/item-surge-alloy.png"></img> Surge Alloy 


*"An advanced alloy with unique electrical properties."*  

| Property      | Value |
| ----------- | ----------- |
|Internal Name|`surge-alloy`|
|Color|`f3e979`|
|Type|Material|
|Flammability|0%|
|Explosiveness|0%|
|Radioactivity|0%|
|Naturally Occurring|No|
|Build Cost|100%|
|Hardness|0|

--- 

##### Produced in <br><a href="/wiki/blocks/crafting/alloy-smelter"><img id="sprlist" src="/wiki/images/block-alloy-smelter-small.png"/></a> 

##### Required for <br><a href="/wiki/blocks/turret/swarmer"><img id="sprlist" src="/wiki/images/block-swarmer-small.png"/></a> <a href="/wiki/blocks/turret/cyclone"><img id="sprlist" src="/wiki/images/block-cyclone-small.png"/></a> 

##### Used to build <br><a href="/wiki/blocks/defense/surge-wall"><img id="sprlist" src="/wiki/images/block-surge-wall-small.png"/></a> <a href="/wiki/blocks/defense/surge-wall-large"><img id="sprlist" src="/wiki/images/block-surge-wall-large-small.png"/></a> <a href="/wiki/blocks/power/surge-tower"><img id="sprlist" src="/wiki/images/block-surge-tower-small.png"/></a> <a href="/wiki/blocks/power/impact-reactor"><img id="sprlist" src="/wiki/images/block-impact-reactor-small.png"/></a> <a href="/wiki/blocks/turret/spectre"><img id="sprlist" src="/wiki/images/block-spectre-small.png"/></a> <a href="/wiki/blocks/turret/meltdown"><img id="sprlist" src="/wiki/images/block-meltdown-small.png"/></a> <a href="/wiki/blocks/upgrade/omega-mech-pad"><img id="sprlist" src="/wiki/images/block-omega-mech-pad-small.png"/></a> <a href="/wiki/blocks/upgrade/glaive-ship-pad"><img id="sprlist" src="/wiki/images/block-glaive-ship-pad-small.png"/></a> 
[comment]: # (WARNING: Do not modify the text above. It is automatically generated every release.)